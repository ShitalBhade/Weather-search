const $ = (id) => document.getElementById(id);
const cityInput = $('cityInput');
const searchBtn = $('searchBtn');
const resultEl = $('result');
const errorEl = $('error');
const loadingEl = $('loading');

function showLoading(show) {
  loadingEl.classList.toggle('hidden', !show);
}

function showError(msg) {
  errorEl.textContent = msg || '';
}

function showResult(data, cached) {
  resultEl.classList.remove('hidden');
  $('cityName').textContent = data.city || '-';
  $('country').textContent = data.country ? (', ' + data.country) : '';
  $('mainDesc').textContent = data.weather_description || data.weather_main || '';
  $('temp').textContent = data.temperature_c != null ? `${data.temperature_c}°C` : '-';
  $('feels').textContent = data.feels_like_c != null ? `${data.feels_like_c}°C` : '-';
  $('humidity').textContent = data.humidity_percent != null ? `${data.humidity_percent}%` : '-';
  $('pressure').textContent = data.pressure_hpa != null ? `${data.pressure_hpa} hPa` : '-';
  $('wind').textContent = data.wind_speed_mps != null ? `${data.wind_speed_mps} m/s` : '-';
  $('sunrise').textContent = data.sunrise_utc ? new Date(data.sunrise_utc).toLocaleString() : '-';
  $('sunset').textContent = data.sunset_utc ? new Date(data.sunset_utc).toLocaleString() : '-';
  $('meta').textContent = `Coords: ${data.coords ? data.coords.lat + ',' + data.coords.lon : '-'} · Timezone offset (s): ${data.timezone_seconds || '-' } · ${cached ? 'From cache' : 'Live fetch'}`;
  if (data.icon) {
    $('weatherIcon').src = data.icon;
    $('weatherIcon').style.display = 'block';
  } else {
    $('weatherIcon').style.display = 'none';
  }
}

async function fetchWeather(city) {
  showLoading(true);
  showError('');
  resultEl.classList.add('hidden');

  try {
    const resp = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
    if (!resp.ok) {
      const err = await resp.json().catch(()=>({error: 'Unknown error'}));
      showError(err.error || 'Failed to fetch weather');
      showLoading(false);
      return;
    }
    const payload = await resp.json();
    showResult(payload.data, payload.cached);
  } catch (err) {
    showError('Network error — could not contact server');
    console.error(err);
  } finally {
    showLoading(false);
  }
}

searchBtn.addEventListener('click', () => {
  const city = cityInput.value.trim();
  if (!city) {
    showError('Please enter a city name.');
    return;
  }
  fetchWeather(city);
});

cityInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') searchBtn.click();
});
